import pandas as pd
import pytest
from reconciler import reconcile, generate_demo_data

def test_demo_exposes_required_gap_types():
    tx, bank = generate_demo_data()
    result = reconcile(tx, bank)
    kinds = set(result["exceptions"]["issue_type"])
    assert "settled_following_month" in kinds
    assert "duplicate_platform_transaction" in kinds
    assert "refund_without_matching_original" in kinds
    assert "multiple_settlements_for_transaction" in kinds
    assert "bank_settlement_without_platform_transaction" in kinds
    assert "aggregate_rounding_difference" in kinds

def test_missing_settlement_detected():
    tx = pd.DataFrame([["A", "2026-01-01", 5, "USD", "payment"]], columns=["transaction_id","transaction_date","amount","currency","type"])
    bank = pd.DataFrame(columns=["settlement_id","transaction_id","settlement_date","amount","currency"])
    result = reconcile(tx, bank)
    assert "missing_settlement" in set(result["exceptions"]["issue_type"])

def test_amount_mismatch_detected():
    tx = pd.DataFrame([["A", "2026-01-01", 5, "USD", "payment"]], columns=["transaction_id","transaction_date","amount","currency","type"])
    bank = pd.DataFrame([["S1","A","2026-01-02",7,"USD"]], columns=["settlement_id","transaction_id","settlement_date","amount","currency"])
    result = reconcile(tx, bank)
    assert "amount_mismatch" in set(result["exceptions"]["issue_type"])

def test_one_cent_difference_is_within_default_tolerance():
    tx = pd.DataFrame([["A", "2026-01-01", 5, "USD", "payment"]], columns=["transaction_id","transaction_date","amount","currency","type"])
    bank = pd.DataFrame([["S1","A","2026-01-02",4.99,"USD"]], columns=["settlement_id","transaction_id","settlement_date","amount","currency"])
    result = reconcile(tx, bank)
    assert "amount_mismatch" not in set(result["exceptions"]["issue_type"])

def test_missing_required_column_fails_clearly():
    with pytest.raises(ValueError, match="missing required columns"):
        reconcile(pd.DataFrame({"transaction_id":["A"]}), pd.DataFrame())
